$(function(){
    //nav
    $('.gnb').click(function(){
        $(this).find('.lnb').toggle()
    });

    //slide

    setInterval(myslide, 3000)
    function myslide(){
        $('.slidein').animate({
            'left' : '-1200px'
        },500, function(){
            $('.slidein img:first-child')
            .clone().appendTo('.slidein');
            $('.slidein img:first-child').remove();
            $('.slidein').css('left',0);
        });
    }
});//jquery